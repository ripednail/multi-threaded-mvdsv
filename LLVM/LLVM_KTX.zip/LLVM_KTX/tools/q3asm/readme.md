q3asm is a tool which compiles assembly files (created by q3lcc from game sources) to QVM bytecode

Major features of this version:

* fast processing (faster even than q3asm-turbo)
* unreferenced code/data elimination
* proper 'static' keyword support
* external jump targets segment (*.jts) generation for quake3e engine