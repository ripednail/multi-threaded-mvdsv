/*
Copyright (C) 1996-1997 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

    
*/
// sv_master.c - send heartbeats to master server

#include "qwsvdef.h"
#include <cilk/cilk.h>
#include <pthread.h>
#include <cilk/cilk_api.h>

#define HEARTBEAT_SECONDS 300
#define NCPUCORES_SECONDS 7
//#define MAX_THREADS 0
//#define FORCE_THREADS 0

extern  cvar_t  sv_maxthreads, sv_minthreads, sv_forcethreads;

static netadr_t master_adr[MAX_MASTERS]; // address of group servers

/*
====================
SV_SetMaster_f

Make a master server current
====================
*/
void SV_SetMaster_f (void)
{
	char data[2];
	int i;

	memset (&master_adr, 0, sizeof(master_adr));

	for (i=1 ; i<Cmd_Argc() ; i++)
	{
		if (!strcmp(Cmd_Argv(i), "none") || !NET_StringToAdr (Cmd_Argv(i), &master_adr[i-1]))
		{
			Con_Printf ("Setting nomaster mode.\n");
			return;
		}
		if (master_adr[i-1].port == 0)
			master_adr[i-1].port = BigShort (27000);

		Con_Printf ("Master server at %s\n", NET_AdrToString (master_adr[i-1]));

		Con_Printf ("Sending a ping.\n");

		data[0] = A2A_PING;
		data[1] = 0;
		NET_SendPacket (NS_SERVER, 2, data, master_adr[i-1]);
	}

	svs.last_heartbeat = -99999;
}

/*
==================
SV_Heartbeat_f
==================
*/
void SV_Heartbeat_f (void)
{
	svs.last_cpucorecheck = svs.last_heartbeat = -99999;
}

/*
================
Master_Heartbeat

Send a message to the master every few minutes to
let it know we are alive, and log information
================
*/
void Master_Heartbeat (void)
{

	if (sv.state != ss_active)
		return;

	if (realtime - svs.last_cpucorecheck > NCPUCORES_SECONDS)
	{
        int active2 = 0;
	int ii;

	svs.last_cpucorecheck = realtime;
        	for (ii=0 ; ii<MAX_CLIENTS ; ii++)
                	if (svs.clients[ii].state == cs_connected || svs.clients[ii].state == cs_spawned )
                        	active2++;

//	sv_maxthreads, sv_forcethreads

//	if ((int)sv_forcethreads.value != FORCE_THREADS)
//                Cvar_SetValue (&sv_forcethreads, FORCE_THREADS);

//	if ((int)sv_maxthreads.value != MAX_THREADS)
//                Cvar_SetValue (&sv_maxthreads, MAX_THREADS);

//	int nthds;
//	if((int)sv_forcethreads.value > 0)
//	{
//	nthds = (int)sv_forcethreads.value;
//	int nworker = __cilkrts_get_nworkers();
//
//                char nthds2[1];
//                sprintf(nthds2, "%d", nthds);
//                if(nworker != nthds)
//                {
//                        __cilkrts_end_cilk();
//                        __cilkrts_set_param("nworkers", nthds2);
//                        __cilkrts_init();
//                }
//	}
//	else
//	{
//		int ncores;
//		if((int)sv_maxthreads.value > 0)
//                ncores = (int)sv_maxthreads.value;
//		else
//		ncores = sysconf(_SC_NPROCESSORS_ONLN);
//
//		if ((active2 < 4 || ncores == 1) && !(int)sv_minthreads.value) { nthds = 1; }
//		else if((ncores <= 4 && ncores > 2 && active2 >= 4 && active2 <= 8) && !(int)sv_minthreads.value) { nthds = 2; }
//		else if((ncores == 2 && active2 >= 4) && !(int)sv_minthreads.value) { nthds = 2; }
//		else
//		{
//		float nthdsmin = active2/( MAX_CLIENTS/ncores );
//		float nthdsmax = active2/( (MAX_CLIENTS/2)/ncores );
//		if (nthdsmin  < 1)	{nthdsmin = 1;}
//		if (nthdsmax  < 1)      {nthdsmax = 1;}
//		if (nthdsmax > ncores)	{nthdsmax = ncores;}
//		nthds =  round( (nthdsmin + nthdsmax)/2 );

//		if (nthds > ncores && (int)sv_maxthreads.value == 0)  {nthds = ncores;}

//		if ( (int)sv_minthreads.value > nthds ) { nthds = (int)sv_minthreads.value;}

//		}

//		int nworker = __cilkrts_get_nworkers();

//		char nthds2[1];
//		sprintf(nthds2, "%d", nthds);
//		if(nworker != nthds)
//		{
//			__cilkrts_end_cilk();
//                        __cilkrts_set_param("nworkers", nthds2);
  //                      __cilkrts_init();
//		}
//	}
	
	return;
        }

	if (realtime - svs.last_heartbeat < HEARTBEAT_SECONDS)
                return; // not time to send yet

	char string[2048];
        int active = 0;
	int i;
	for (i=0 ; i<MAX_CLIENTS ; i++)
                        if (svs.clients[i].state == cs_connected || svs.clients[i].state == cs_spawned )
                                active++;

	svs.last_heartbeat = realtime;


	svs.heartbeat_sequence++;
	snprintf (string, sizeof(string), "%c\n%i\n%i\n", S2M_HEARTBEAT,
		  svs.heartbeat_sequence, active);

	// send to group master
	for (i=0 ; i<MAX_MASTERS ; i++)
		if (master_adr[i].port)
		{
			Con_Printf ("Sending heartbeat to %s\n", NET_AdrToString (master_adr[i]));
			NET_SendPacket (NS_SERVER, strlen(string), string, master_adr[i]);
		}
}

/*
=================
Master_Shutdown

Informs all masters that this server is going down
=================
*/
void Master_Shutdown (void)
{
	char string[2048];
	int i;

	snprintf (string, sizeof(string), "%c\n", S2M_SHUTDOWN);

	// send to group master
	for (i=0 ; i<MAX_MASTERS ; i++)
		if (master_adr[i].port)
		{
			Con_Printf ("Sending heartbeat to %s\n", NET_AdrToString (master_adr[i]));
			NET_SendPacket (NS_SERVER, strlen(string), string, master_adr[i]);
		}
}

