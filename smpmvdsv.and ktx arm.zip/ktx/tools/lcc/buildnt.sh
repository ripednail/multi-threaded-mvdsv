#!/bin/sh
export BUILDDIR=.\\out
mkdir out
nmake -f makefile.nt all
